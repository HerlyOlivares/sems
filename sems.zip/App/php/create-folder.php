<?php 
if (isset($_POST['new-folder'])) {
 	
 	$id = $_POST['new-folder'];

 	 mkdir('../data/'.$id, 0777);
 } 
	
?>