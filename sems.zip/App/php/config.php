<?php //Datos de conexión a la base de datos
$hostname = 'localhost';
$database = 'datos';
$username = 'usuario';
$password = 'contraseña';
?>