function create_folder(){
	
		if($('.new-folder-box').val() == ""){
			        alert("El campo Nombre no puede estar vacío.");
			        $('.new-folder-box').focus();// Esta función coloca el foco de escritura del usuario en el campo Nombre directamente.
			        return false;
			    }else 	{
								

							$.ajax({
									    
									    type: 'POST',
									    data: $('.new-folder-box').serialize(),
									    url: '../App/php/create-folder.php',
									     dataType: 'json',
									    
									    success: function() {
									      	
											$("#fracaso").delay(500).fadeIn("slow");
									    },
									    error: function(){
									      
									      	$(".formdata").fadeOut("slow");		
											$("#exito").delay(500).fadeIn("slow");
											$("#new-folder").delay(2000).fadeOut("slow");
									      
											/*   recargar contenido de tablas */
												/* tabla side lateral*/
												$("#rolling").fadeIn("slow");
											  	$("#content-side-nav").css('opacity', 0.6);
											  	$("#content-side-nav").load('home.php?randval='+ Math.random() + " #content-side-repo", function(){
											      //aquí puedes meter más código si necesitas;
											      $("#content-side-nav").css('opacity', 1);
											      $("#rolling").fadeOut("slow");
											  	});

											  	/* tabla principal */
											  	$("#rolling-body").fadeIn("slow");
											  	$("#panel").css('opacity', 0.6);
											  	$("#panel").load('home.php?randval='+ Math.random() + " #panel-body", function(){
											      
												      		$(".formdata").fadeOut("slow");		
														$("#exito").delay(500).fadeIn("slow");
														$("#new-folder").delay(2000).fadeOut("slow");
												      	
												      	$("#panel").css('opacity', 1);
											      		$("#rolling-body").fadeOut("slow");
											  	});
									    }
									   });
						
						};
	
}

function delete_folder(){
	
	
			var link = $(this).attr('tittle');
			var data = $(this).attr('data');

							$.ajax({
									    
									    type: 'POST',
									    data:{url:link},
									     url: '../App/php/delete-folder.php',
									     dataType: 'json',
									    
									    success: function() {
									      	
											$("#resp-delete-none").delay(500).fadeIn("slow");
									    },
									    error: function(){
									      
									      /*	$("#formdata").fadeOut("slow");	*/	
											$("#resp-delete").delay(500).fadeIn("slow");
											
											/* tabla side lateral*/
												$("#rolling").fadeIn("slow");
											  	$("#content-side-nav").css('opacity', 0.6);
											  	$("#content-side-nav").load('home.php?randval='+ Math.random() + " #content-side-repo", function(){
											      //aquí puedes meter más código si necesitas;
											      $("#content-side-nav").css('opacity', 1);
											      $("#rolling").fadeOut("slow");
											  	});
											  	
											  	/**********/
											
											  	$("#panel").css('opacity', 0.6);
											  	$("#panel").load('home.php'+ " #panel-body", function(){
											      
												      		$("#formdata").fadeOut("slow");		
														$("#resp-delete").delay(500).fadeOut("slow");
														
												      	
												      	$("#panel").css('opacity', 1);
											      		
											  	});
									    }
							}); /* ajax */
						
						
		
}


$(document).ready(function() {

		/* ligthbox */
		$(".Login").click(function() {
                 var h = $(window).height() + 'px';
                 $("#black_overlay").css({"height":h,"visibility":"visible"});
                 $(".added").css('display','block');
              });
             
              $(".close").click(function() {
                 $(".added").css('display','none');
                 $("#black_overlay").css("visibility","hidden");
              });
              $("#black_overlay").click(function() {
                 $(".added").css('display','none');
                 $("#black_overlay").css("visibility","hidden");
              });
         /****************************************************************************************/

		$('#new-folder').fadeOut(.000001);

        $('#dataTables-example').DataTable({
                responsive: true
        });
  
 	
	$('.new-folder').click(function() {
		event.preventDefault();
		
		/*$('#new-folder').removeClass('new-folder-none');*/
		$('#new-folder').fadeIn("slow");
		$(".formdata").fadeIn("slow");
		$("#exito").fadeOut(.000001);
		$('.new-folder-box').focus();
	});


		

/************************************************ borrar carpetas ************************************************/

	
			
			

});/* document ready */